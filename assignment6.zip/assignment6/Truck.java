package kz.aitu.oop.assignment6;
public class Truck implements Transport {
	@Override
	public void delivering() {
		System.out.println("Delivering within the land in the special box");
	}
}