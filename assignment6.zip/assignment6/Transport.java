package kz.aitu.oop.assignment6;
public interface Transport {
	void delivering();
}