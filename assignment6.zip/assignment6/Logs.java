package kz.aitu.oop.assignment6;
public class Logs {
	public Transport createTransport() {
		return null;
		};
	public void planDelivery () {
	};
}