package kz.aitu.oop.assignment6;
public class Ship implements Transport {
	@Override
	public void delivering() {
		System.out.println("Delivering within the sea in the special container");
	}
}